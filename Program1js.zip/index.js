let a = 23;
//console.log(A); Error A is not defined
console.log(a);