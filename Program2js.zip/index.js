let y = 24;

let Y = 42;

console.log(Y);
